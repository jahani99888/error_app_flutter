
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' as rootBundle;

void main() {
  runApp(const ErrorApp());
}

class ErrorApp extends StatelessWidget {
  const ErrorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'System Errors',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const ErrorListPage(),
    );
  }
}

class ErrorItem {
  final int id;
  final String title;
  final String env;
  final String option;
  final String message;
  final String cause;
  final String solution;
  final List<String> tags;

  ErrorItem({
    required this.id,
    required this.title,
    required this.env,
    required this.option,
    required this.message,
    required this.cause,
    required this.solution,
    required this.tags,
  });

  factory ErrorItem.fromJson(Map<String, dynamic> json) {
    return ErrorItem(
      id: json['id'],
      title: json['title'],
      env: json['env'],
      option: json['option'],
      message: json['message'],
      cause: json['cause'],
      solution: json['solution'],
      tags: List<String>.from(json['tags']),
    );
  }
}

class ErrorListPage extends StatefulWidget {
  const ErrorListPage({super.key});

  @override
  State<ErrorListPage> createState() => _ErrorListPageState();
}

class _ErrorListPageState extends State<ErrorListPage> {
  List<ErrorItem> _errors = [];
  List<ErrorItem> _filtered = [];

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {
    final jsondata = await rootBundle.rootBundle.loadString('assets/error_messages.json');
    final list = json.decode(jsondata) as List<dynamic>;
    setState(() {
      _errors = list.map((e) => ErrorItem.fromJson(e)).toList();
      _filtered = _errors;
    });
  }

  void _search(String query) {
    setState(() {
      _filtered = _errors.where((item) =>
        item.title.toLowerCase().contains(query.toLowerCase()) ||
        item.message.toLowerCase().contains(query.toLowerCase()) ||
        item.cause.toLowerCase().contains(query.toLowerCase())
      ).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پیام‌های خطا')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: const InputDecoration(
                labelText: 'جستجو...',
                border: OutlineInputBorder(),
              ),
              onChanged: _search,
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _filtered.length,
              itemBuilder: (context, index) {
                final err = _filtered[index];
                return ListTile(
                  title: Text(err.title),
                  subtitle: Text(err.message),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ErrorDetailPage(error: err),
                      ),
                    );
                  },
                );
              },
            ),
          )
        ],
      ),
    );
  }
}

class ErrorDetailPage extends StatelessWidget {
  final ErrorItem error;
  const ErrorDetailPage({super.key, required this.error});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(error.title)),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('محیط: ${error.env}', style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('گزینه: ${error.option}'),
              const SizedBox(height: 10),
              Text('پیام خطا:', style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(error.message),
              const SizedBox(height: 10),
              Text('علت مشکل:', style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(error.cause),
              const SizedBox(height: 10),
              Text('روش رفع:', style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(error.solution),
            ],
          ),
        ),
      ),
    );
  }
}
